P = [1 2 3 4];
A = sim(net,P)



P = {[1 4] [2 3] [3 2] [4 1]};
A = sim(net,P);